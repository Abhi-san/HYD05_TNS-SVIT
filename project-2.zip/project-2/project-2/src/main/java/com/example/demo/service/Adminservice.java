package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Admin;

public interface Adminservice {

	Admin saveAdmin(Admin admin);

	List<Admin> fetchAdminList();

	Admin fetchAdminById(Long id);

	void deleteAdminById(Long id);

	Admin updateAdmin(Long id, Admin admin);

}
