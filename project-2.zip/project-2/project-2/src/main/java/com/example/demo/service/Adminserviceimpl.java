package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Admin;
import com.example.demo.repository.Adminrepo;



@Service
public class Adminserviceimpl implements Adminservice {
	
	 @Autowired
	    private Adminrepo ad;

	    @Override
	    public Admin saveAdmin(Admin  admin ) {
	        return ad.save(admin);
	    }

	    @Override
	    public List<Admin > fetchAdminList() {
	        return ad.findAll();
	    }

	   @Override
	   public Admin  fetchAdminById(Long id) {
		   return ad.findById(id).get();
	   }
		
	   @Override
	   public void deleteAdminById(Long id) {
	       ad.deleteById(id);
	   }


	   @Override
	   public Admin  updateAdmin (Long id, Admin  admin) {
		   Admin admins= ad.findById(id).get();

	       if(Objects.nonNull(admin.getName()) &&
	       !"".equalsIgnoreCase(admin.getName())) {
	           admins.setName(admin.getName());
	       }

	       if(Objects.nonNull(admin.getPassword()) &&
	               !"".equalsIgnoreCase(admin.getPassword())) {
	           admins.setPassword(admin.getPassword());
	       }

	       

	       return ad.save(admins);
	   }

	    
	    

}
